from rest_framework import serializers
from .models import Emp,Account,Project

class EmpSerializer(serializers.ModelSerializer):
    pro_emp=serializers.PrimaryKeyRelatedField(many=True,queryset=Project.objects.all())
    emp_account=serializers.PrimaryKeyRelatedField(many=True,queryset=Account.objects.all())
    class Meta:
        model=Emp
        fields=["id","name","email","contact","age","emp_account",'pro_emp']


from django.contrib.auth.models import User
class UserSerializer1(serializers.ModelSerializer):
    acc_owner=serializers.PrimaryKeyRelatedField(many=True,queryset=Account.objects.all())
    pro_owner=serializers.PrimaryKeyRelatedField(many=True,queryset=Project.objects.all())
    class Meta:
        model=User
        fields=["id","username","first_name","email","acc_owner",'pro_owner']

class UserSerializer2(serializers.HyperlinkedModelSerializer):
    acc_owner=serializers.PrimaryKeyRelatedField(many=True,queryset=Account.objects.all())
    pro_owner=serializers.PrimaryKeyRelatedField(many=True,queryset=Project.objects.all())
    class Meta:
        model=User
        fields=["url","id","username","first_name","email","acc_owner",'pro_owner']



class AccountSerializer(serializers.ModelSerializer):
    class Meta:
        model=Account
        fields="__all__"

class ProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model=Project
        fields="__all__"