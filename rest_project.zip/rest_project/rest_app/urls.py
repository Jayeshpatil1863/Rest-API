from django.urls import path
from .import views as v


urlpatterns = [
    path('', v.home),
    # path("addemp",v.CreateEmp.as_view()),
    # path('listemp',v.ListEmp.as_view()),
    # path("gemp/<int:pk>",v.GetEmp.as_view()),
    # path("uemp/<int:pk>",v.UpdateEmp.as_view()),
    # path('demp/<int:pk>',v.DeleteEmp.as_view()),

    # All Separate Crud Operation


    path('lcemp',v.ListCreateEmp.as_view()),
    path('gudemp/<int:pk>',v.GUDEmp.as_view()),

]
