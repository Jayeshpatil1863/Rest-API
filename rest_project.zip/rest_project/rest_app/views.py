from django.shortcuts import render,HttpResponse

def home(request):
    return HttpResponse("<h2>Hello API</h2>")


from rest_framework import generics
from .serializer import Emp,EmpSerializer
# class CreateEmp(generics.CreateAPIView):
#     serializer_class=EmpSerializer

# class ListEmp(generics.ListAPIView):
#     queryset=Emp.objects.all()
#     serializer_class=EmpSerializer


# class GetEmp(generics.RetrieveAPIView):
#     queryset=Emp.objects.all()
#     serializer_class=EmpSerializer

# class UpdateEmp(generics.UpdateAPIView):
#     queryset=Emp.objects.all()
#     serializer_class=EmpSerializer

# class DeleteEmp(generics.DestroyAPIView):
#     queryset=Emp.objects.all()
#     serializer_class=EmpSerializer

class ListCreateEmp(generics.ListCreateAPIView):
    queryset=Emp.objects.all()
    serializer_class=EmpSerializer

class GUDEmp(generics.RetrieveUpdateDestroyAPIView):
    queryset=Emp
    serializer_class=EmpSerializer



from .serializer import UserSerializer1,UserSerializer2,User,Account,AccountSerializer,Project,ProjectSerializer
from rest_framework import viewsets

class CRUDUser1(viewsets.ModelViewSet):
    queryset=User.objects.all()
    serializer_class=UserSerializer1 


class CRUDUser2(viewsets.ModelViewSet):
    queryset=User.objects.all()
    serializer_class=UserSerializer2 


class CRUDAccount(viewsets.ModelViewSet):
    queryset=Account.objects.all()
    serializer_class=AccountSerializer

class CRUDProject(viewsets.ModelViewSet):
    queryset=Project.objects.all()
    serializer_class=ProjectSerializer