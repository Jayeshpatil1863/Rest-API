from django.db import models
from django.contrib.auth.models import User

class Emp(models.Model):
    name=models.CharField(max_length=30)
    email=models.EmailField(max_length=30)
    contact=models.IntegerField()
    age=models.IntegerField()

    class Meta:
        db_table="emp"

    def __str__(self):
        return self.name
    

class Account(models.Model):
    salary=models.IntegerField()
    month=models.CharField(max_length=30)
    emp=models.ForeignKey(Emp,on_delete=models.CASCADE,related_name="emp_account")
    owner=models.ForeignKey(User,on_delete=models.CASCADE,related_name="acc_owner")


class Project(models.Model):
    name=models.CharField(max_length=30)
    description=models.TextField(max_length=300)
    pro_owner=models.ForeignKey(User,related_name="pro_owner",on_delete=models.CASCADE)
    pro_emp=models.ManyToManyField(Emp,related_name="pro_emp")