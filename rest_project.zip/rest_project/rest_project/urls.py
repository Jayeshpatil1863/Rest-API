
from django.contrib import admin
from django.urls import path,include
from rest_framework import routers
from rest_app.views import CRUDUser1,CRUDUser2,CRUDAccount,CRUDProject


rt=routers.DefaultRouter()
rt.register('user1',CRUDUser1, basename='user1')
rt.register('user2',CRUDUser2)
rt.register("acc",CRUDAccount)
rt.register('proj',CRUDProject)


urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include("rest_app.urls")),
    path('',include(rt.urls)),
]
